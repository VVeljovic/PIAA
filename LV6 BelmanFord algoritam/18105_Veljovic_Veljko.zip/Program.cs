﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Bellman_Ford
{

    class Program
    {
        public static void SetStatusForAllNodes(int st,Graph g)
        {
            Node ptr = g.start;
            while(ptr != null)
            {
                ptr.status = st;
                ptr = ptr.next;
            }
        }
        public static void BellmanFord(Graph g, int s,int d)
        {

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();


            //svima na beskonacno
            Node ptr = new Node(-1);
            Node odr = new Node(-1);
            Node iter = g.start;
            while (iter != null)
            {
                if(iter.node==s)
                {
                    ptr = iter;
                }
                if(iter.node==d)
                {
                    odr = iter;
                }
                iter.d = Int32.MaxValue;
                iter.prethodnik = null;
                iter = iter.next;
            }
            if(odr.node==-1 || ptr.node==-1)
            {
                Console.WriteLine("Odredisni ili izvorisni cvor ne postoji.");
                return; 
            }
            Node polazni = ptr;
            polazni.d = 0;
            //relaksacija //za svaki poteg V-1 put! pocesvsi od cvora s
            for (int i = 0; i < g.nodeNum-1; i++)
            {
                SetStatusForAllNodes(1, g);
                QueueAsArrayNodes queue = new QueueAsArrayNodes(g.nodeNum);
                ptr = polazni;
                queue.enqueue(ptr);
                ptr.status = 2; 
                while (!queue.isEmpty())
                {
                    ptr = queue.dequeue();
                    ptr.status = 3;
                    Edge a = ptr.adj;
                    while (a != null)
                    {
                        if(a.dest.status==1)
                        {
                            queue.enqueue(a.dest);
                            a.dest.status = 2;
                        }
                        if (a.dest.d > ptr.d + a.weight)
                        {
                            a.dest.d = ptr.d + a.weight;
                            a.dest.prethodnik = ptr;
                           // Console.WriteLine($"Poteg izmedju cvora{ptr.node} i {a.dest.node} je relaksiran na {a.dest.d} ");
                        }
                        a = a.link;
                    }
                   
                    
                }
            }
            ptr = g.start;
            while(ptr != null)
            {
                Edge b = ptr.adj;
                while(b!=null)
                {
                    if(ptr.d!=Int32.MaxValue&&b.dest.d>ptr.d+b.weight)
                    {
                        Console.WriteLine("Postoji negativan ciklus i nema resenja !");
                        return;
                    }
                    b = b.link;
                }
                ptr = ptr.next;
            }
            ptr = g.start;
           
                
            stopWatch.Stop();
            TimeSpan ts = stopWatch.Elapsed;
            Console.WriteLine();
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
            ts.Hours, ts.Minutes, ts.Seconds,
            ts.Milliseconds / 10);
            Console.WriteLine("BelmanFord algoritam za graf od " + g.nodeNum + " cvorova se izvrsio za " + elapsedTime);
            Console.WriteLine($"Udaljenost cvora {odr.node} od pocetnog cvora {polazni.node} je {odr.d}");

        }
        public static void DaisyChain(Dictionary<string, int> potezi, Graph a, Node cv)
        {
            Node iter = a.start;
            //cv je cvor koji spajamo sa svima 
            while (iter != null)
            {
                if (iter.node != cv.node) //pocetni cvor ne smemo da povezemo sa samim sobom
                {
                    int n1 = iter.node;
                    int n2 = cv.node;
                    string s1 = n1.ToString();
                    string s2 = n2.ToString();
                    s1 += s2;  //pravimo kljuc 
                    Random rnd = new Random();
                    int weig = rnd.Next(1, 100);
                    a.insertEdge(iter.node, weig, cv.node); // dodamo u graf i dictionary potez izmedju tekuceg cvora i cvora CV
                    a.insertEdge(cv.node, weig, iter.node);
                    potezi.TryAdd(s1, n1);
                }
                iter = iter.next;

            }
        }
        public static void FirstCase(Dictionary<string, int> potezi, Graph a)
        {
            Node iter2 = a.start;
            Random tezinapoteg = new Random();
            int tezina = tezinapoteg.Next(1, 100);
            string s1 = "", s2 = "";
            while (iter2.next != null) // krecem se sve dok ne dodjem do poslednjeg cvora
            {
                tezinapoteg = new Random();
                tezina = tezinapoteg.Next(1, 100);
                a.insertEdge(iter2.node, tezina, iter2.next.node); //dodajem poteg izmedju tekuceg cvora i cvora ispred njega
                a.insertEdge(iter2.next.node, tezina, iter2.node);
                s1 = iter2.node.ToString();
                s2 = iter2.next.node.ToString();
                s1 += s2; //pravim kljuc za potege 
                potezi.TryAdd(s1, iter2.node); //dodavanje poteza u dictionary
                iter2 = iter2.next;
            }
            tezina = tezinapoteg.Next(1, 100);
            a.insertEdge(iter2.node, tezina, a.start.node); //kad sam dosao do poslednjeg cvora u listi cvorova njega spajam sa prvim 
            a.insertEdge(a.start.node, tezina, iter2.node); //prvi spajam sa poslednjim
            s1 = iter2.node.ToString();
            s2 = a.start.node.ToString();
            s1 += s2;
            potezi.TryAdd(s1, iter2.node);
        }
        public static void GenerisiKNpotega(Dictionary<string, int> potezi, Graph a, Dictionary<int, Node> recnik, int kn)
        {
            int ii = 0;
            while (ii < kn)
            {
                Random rnd = new Random();
                int num1 = rnd.Next(0, recnik.Count - 1); //pronalazak 2 random cvora iz recnika
                int num2 = rnd.Next(0, recnik.Count - 1);
                while (num1 == num2) //ukoliko je izgenerisao 2 ista cvora trazim da generise novi 
                    num1 = rnd.Next(0, recnik.Count - 1);
                int weig = rnd.Next(1, 100);
                int prvicv = recnik.ElementAt(num1).Key;
                int drugicv = recnik.ElementAt(num2).Key;
                string s1 = prvicv.ToString();
                string s2 = drugicv.ToString();
                s1 += s2; // pravljenje kljuca 
                if (potezi.TryAdd(s1, num1))//Koristim jako bitnu odliku dictionary-ja da ne mogu da postoje 2 elementa sa istim kljucem
                {                           //tj.ako vec postoji poteg u dictionary-ju then grana se ne izvrsava,puno efikasnije nego da prolazim kroz listu potega
                                            //i proveravam da li postoji grana
                    a.insertEdge(prvicv, weig, drugicv);
                    a.insertEdge(drugicv, weig, prvicv);
                    ii++;
                }
                else
                {
                    // Console.WriteLine($"Potez Vec postoji izmedju cvorova {prvicv} i {drugicv}");
                }


            }
        }
        static void Main(string[] args)
        {
            Graph a = new Graph();
            Console.WriteLine("Unesite N cvorova:");
            string num = Console.ReadLine();
            int n = Convert.ToInt32(num);
            Dictionary<int, Node> recnik = new Dictionary<int, Node>();//koristim recnik,gde cu osim u graf,cvorove da ubacujem i u ovaj recnik radi efikasnijeg pristupa cvorovima
            int i = 0;
            while (i < n)
            {
                Random rnd = new Random();
                int br = rnd.Next(0, 150000);
                Node novicvor = new Node(br);
                if (recnik.TryAdd(br, novicvor)) //ukoliko cvor uspesno dodam u recnik
                {
                    i++; // 
                    a.insertNode(br); //dodam i u graf
                }
            }
            Dictionary<string, int> potezi = new Dictionary<string, int>();//pravim takodje recnik za poteze razlog uvodjenja je isti kao i za grafove,
            //kljuc za ovaj dictionary je string tj ako potez cine cvorovi 3 i 5 kljuc ce biti "35"
            Console.WriteLine("Unesite 1 ukoliko zelite da se izvrsi slucaj 1,unesite 2 ukoliko zelite da se izvrsi slucaj 2 "); //slucaj 1 i 2 su oni kao na timsu opisani
            string slucaj = Console.ReadLine();
            int sl = Convert.ToInt32(slucaj);
            if (sl == 2)
            {
                Random rnd2 = new Random();
                int br2 = rnd2.Next(0, n - 1); //pronalazimo iz recnika neki random cvor i njega povezujemo sa svima
                Node cv = recnik.ElementAt(br2).Value;
                DaisyChain(potezi, a, cv);

            }
            if (sl == 1)
            {
                FirstCase(potezi, a);

            }
            Console.WriteLine("Unesite k za potege pa ce se izgenerisati k*N potega");
            num = Console.ReadLine();
            int k = Convert.ToInt32(num);
            int kn = k * n;
            GenerisiKNpotega(potezi, a, recnik, kn);
            int brpok = 0;
            while (brpok < 10)
            {
                Random ind = new Random();
                int pp = ind.Next(0,n-1); //biramo 2 random cvora iz opsega u dictionary ju i izmedju njih trazimo najkraci put i tako 10 puta
                int pp2 = ind.Next(0,n-1);
                BellmanFord(a, recnik.ElementAt(pp).Key, recnik.ElementAt(pp2).Key);
                brpok++;
            }

        }
    }
}

