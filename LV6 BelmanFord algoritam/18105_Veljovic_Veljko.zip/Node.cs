﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bellman_Ford
{
    class Node
    {
        public int node;
        public Edge adj;
        public Node next;
        public int d;
        public Node prethodnik;
        public int status;
        public Node()
        {
            node = 0;
            adj = null;
            next = null;
            d = 0;
            status = 0;
        }
        public Node(int nodeN)
        {
            node = nodeN;
            adj = null;
            next = null;
            d = 0;
            status = 0;
        }
        public Node(int nodeN, Edge a, Node n)
        {
            node = nodeN;
            adj = a;
            next = n;
            d = 0;
            prethodnik = null;
            status = 0;
        }
        public Node(int nodeN, Edge a, Node n, int dd,int statuss)
        {
            node = nodeN;
            adj = a;
            next = n;
            d = dd;
            status = statuss;
        }
        public void visit()
        {
            Console.Write(node);
        }
    }
}