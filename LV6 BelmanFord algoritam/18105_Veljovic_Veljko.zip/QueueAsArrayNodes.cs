﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bellman_Ford
{
    class QueueAsArrayNodes
    {
        public Node[] arr;
        public int size;
        public int head;
        public int tail;
        public int numOfEl;
       public QueueAsArrayNodes(int size)
        {
            this.size = size;
            arr = new Node[this.size];
            head = tail = -1;
            numOfEl = 0;
        }
        public bool isEmpty()
        {
            return (numOfEl == 0);
        }
        public Node getHead()
        {
            if (numOfEl == 0)
                throw new Exception("Greska!");
            return arr[head];
        }
        public void enqueue(Node obj)
        {
            if(numOfEl==size)
                throw new Exception("Greska!");
            if (++tail == size) tail = 0;
            arr[tail] = obj;
            if (numOfEl == 0) head = tail;
            numOfEl++;
        }
        public Node dequeue()
        {
            if (numOfEl == 0)
                throw new Exception("Greska!");
            Node res = arr[head];
            if (++head == size) head = 0;
            numOfEl--;
            if (numOfEl == 0) head = tail = -1;
            return res;
        }
    }
}
